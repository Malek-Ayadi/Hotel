-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  mer. 11 avr. 2018 à 15:16
-- Version du serveur :  5.7.19
-- Version de PHP :  5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `projet`
--

-- --------------------------------------------------------

--
-- Structure de la table `chambre`
--

DROP TABLE IF EXISTS `chambre`;
CREATE TABLE IF NOT EXISTS `chambre` (
  `id_chamb` int(11) NOT NULL AUTO_INCREMENT COMMENT 'L''id de la chambre (numéro de la chambre) ',
  `id_res` int(11) NOT NULL COMMENT 'id de la réservation (null si la chambre n''est pas reservée)',
  PRIMARY KEY (`id_chamb`),
  KEY `id_res` (`id_res`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `id_clt` int(11) NOT NULL AUTO_INCREMENT COMMENT 'L''id du client',
  `nom` varchar(255) NOT NULL COMMENT 'le nom du client',
  `prenom` varchar(255) NOT NULL COMMENT 'le prenom du client ',
  `ddn` date NOT NULL COMMENT 'la date de naissance du client',
  `mail` varchar(255) NOT NULL COMMENT 'l''adresse email du client',
  `adresse` varchar(255) NOT NULL COMMENT 'l''adresse du client',
  `cin` int(11) NOT NULL COMMENT 'la carte d''identité nationale du client',
  `tel` int(11) NOT NULL COMMENT 'le numéro du téléphone du client',
  PRIMARY KEY (`id_clt`),
  UNIQUE KEY `id_clt` (`id_clt`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `consommation`
--

DROP TABLE IF EXISTS `consommation`;
CREATE TABLE IF NOT EXISTS `consommation` (
  `id_clt` int(11) NOT NULL,
  `id_produit` int(11) NOT NULL,
  `nbr` int(11) NOT NULL COMMENT 'nbr de consommation du produit',
  KEY `id_clt` (`id_clt`),
  KEY `id_produit` (`id_produit`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  `login` varchar(255) NOT NULL COMMENT 'login (unique) du réceptionniste',
  `password` varchar(255) NOT NULL COMMENT 'le mot de passe du réceptionniste',
  `admin` tinyint(1) NOT NULL COMMENT 'admin ou nn',
  `nom` varchar(50) NOT NULL COMMENT 'nom user',
  `prenom` varchar(50) NOT NULL COMMENT 'prenom user',
  `mail` varchar(255) NOT NULL COMMENT 'mail user',
  PRIMARY KEY (`login`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `employee`
--

INSERT INTO `employee` (`login`, `password`, `admin`, `nom`, `prenom`, `mail`) VALUES
('Skander', '123456', 0, 'Meziane', 'Skander', 'meziane.skander@outlook.fr'),
('Malek', '123456', 1, 'Ayadi', 'Malek', 'ayadi.malek@gmail.com'),
('Khlil', '123456', 0, 'Turki', 'Khlil', 'khlilturki97@gmail.com'),
('Ahmed', '123456', 0, 'Haj Yahmed', 'Ahmed', 'hajyahmedboh@yahoo.com'),
('Amine', '123456', 0, 'Karoui', 'Amine', 'aminekaroui7@gmail.com'),
('Yahya', '123456', 0, 'Derbeli', 'Yahya', 'derbeliy97@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

DROP TABLE IF EXISTS `produit`;
CREATE TABLE IF NOT EXISTS `produit` (
  `id_produit` int(11) NOT NULL COMMENT 'L''id de consomation',
  `libellé` int(11) NOT NULL COMMENT 'Le nom de la consommation',
  `prix` int(11) NOT NULL COMMENT 'le prix de la consommation',
  PRIMARY KEY (`id_produit`),
  UNIQUE KEY `id_cons` (`id_produit`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
CREATE TABLE IF NOT EXISTS `reservation` (
  `id_res` int(11) NOT NULL AUTO_INCREMENT COMMENT 'L''id de réservation',
  `id_clt` int(11) NOT NULL COMMENT 'L''id de client',
  `dateArr` date NOT NULL COMMENT 'Date Arrivé du client',
  `dateDep` date NOT NULL COMMENT 'Date départ du client',
  PRIMARY KEY (`id_res`),
  UNIQUE KEY `id_clt` (`id_clt`),
  UNIQUE KEY `id_res` (`id_res`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `reservation`
--

INSERT INTO `reservation` (`id_res`, `id_clt`, `dateArr`, `dateDep`) VALUES
(1, 12, '2018-04-11', '2018-04-18');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `consommation`
--
ALTER TABLE `consommation`
  ADD CONSTRAINT `id_clt` FOREIGN KEY (`id_clt`) REFERENCES `client` (`id_clt`),
  ADD CONSTRAINT `id_produit` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
