-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  jeu. 12 avr. 2018 à 22:31
-- Version du serveur :  5.7.19
-- Version de PHP :  5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `projet1`
--

-- --------------------------------------------------------

--
-- Structure de la table `chambre`
--

DROP TABLE IF EXISTS `chambre`;
CREATE TABLE IF NOT EXISTS `chambre` (
  `id_chamb` int(11) NOT NULL AUTO_INCREMENT COMMENT 'L''id de la chambre (numéro de la chambre) ',
  `id_res` int(11) DEFAULT NULL COMMENT 'id de la réservation (null si la chambre n''est pas reservée)',
  `type` varchar(11) NOT NULL,
  PRIMARY KEY (`id_chamb`),
  KEY `id_res` (`id_res`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `chambre`
--

INSERT INTO `chambre` (`id_chamb`, `id_res`, `type`) VALUES
(57, NULL, 'simple'),
(58, NULL, 'simple'),
(59, NULL, 'simple'),
(60, NULL, 'simple'),
(61, NULL, 'simple'),
(62, NULL, 'simple'),
(63, NULL, 'simple'),
(64, NULL, 'simple'),
(65, NULL, 'simple'),
(66, NULL, 'simple'),
(67, NULL, 'simple'),
(68, NULL, 'simple'),
(69, NULL, 'simple'),
(70, NULL, 'simple'),
(71, NULL, 'simple'),
(72, NULL, 'simple'),
(73, NULL, 'simple'),
(74, NULL, 'simple'),
(75, NULL, 'simple'),
(76, NULL, 'simple'),
(77, NULL, 'double'),
(78, NULL, 'double'),
(79, NULL, 'double'),
(80, NULL, 'double'),
(81, NULL, 'double'),
(82, NULL, 'double'),
(83, NULL, 'double'),
(84, NULL, 'double'),
(85, NULL, 'double'),
(86, NULL, 'double'),
(87, NULL, 'double'),
(88, NULL, 'double'),
(89, NULL, 'double'),
(90, NULL, 'double'),
(91, NULL, 'double'),
(92, NULL, 'triple'),
(93, NULL, 'triple'),
(94, NULL, 'triple'),
(95, NULL, 'triple'),
(96, NULL, 'triple'),
(97, NULL, 'triple'),
(98, NULL, 'triple'),
(99, NULL, 'triple'),
(100, NULL, 'triple'),
(101, NULL, 'triple');

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `id_clt` int(11) NOT NULL AUTO_INCREMENT COMMENT 'L''id du client',
  `nom` varchar(255) NOT NULL COMMENT 'le nom du client',
  `prenom` varchar(255) NOT NULL COMMENT 'le prenom du client ',
  `ddn` date NOT NULL COMMENT 'la date de naissance du client',
  `mail` varchar(255) NOT NULL COMMENT 'l''adresse email du client',
  `adresse` varchar(255) NOT NULL COMMENT 'l''adresse du client',
  `cin` int(11) NOT NULL COMMENT 'la carte d''identité nationale du client',
  `tel` int(11) NOT NULL COMMENT 'le numéro du téléphone du client',
  PRIMARY KEY (`id_clt`),
  UNIQUE KEY `id_clt` (`id_clt`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`id_clt`, `nom`, `prenom`, `ddn`, `mail`, `adresse`, `cin`, `tel`) VALUES
(1, 'aa', '2', '2018-04-12', 'aa@gb', 'cfvghbjn', 456, 845);

-- --------------------------------------------------------

--
-- Structure de la table `consommation`
--

DROP TABLE IF EXISTS `consommation`;
CREATE TABLE IF NOT EXISTS `consommation` (
  `id_cons` int(11) NOT NULL AUTO_INCREMENT,
  `id_clt` int(11) NOT NULL,
  `id_produit` int(11) NOT NULL,
  PRIMARY KEY (`id_cons`),
  KEY `id_clt` (`id_clt`),
  KEY `id_produit` (`id_produit`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `consommation`
--

INSERT INTO `consommation` (`id_cons`, `id_clt`, `id_produit`) VALUES
(1, 1, 2);

-- --------------------------------------------------------

--
-- Structure de la table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  `login` varchar(255) NOT NULL COMMENT 'login (unique) du réceptionniste',
  `password` varchar(255) NOT NULL COMMENT 'le mot de passe du réceptionniste',
  `admin` tinyint(1) NOT NULL COMMENT 'admin ou nn',
  `nom` varchar(50) NOT NULL COMMENT 'nom user',
  `prenom` varchar(50) NOT NULL COMMENT 'prenom user',
  `mail` varchar(255) NOT NULL COMMENT 'mail user',
  PRIMARY KEY (`login`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `employee`
--

INSERT INTO `employee` (`login`, `password`, `admin`, `nom`, `prenom`, `mail`) VALUES
('Skander', '123456', 0, 'Meziane', 'Skander', 'meziane.skander@outlook.fr'),
('Malek', '123456', 1, 'Ayadi', 'Malek', 'ayadi.malek@gmail.com'),
('Khlil', '123456', 0, 'Turki', 'Khlil', 'khlilturki97@gmail.com'),
('Ahmed', '123456', 0, 'Haj Yahmed', 'Ahmed', 'hajyahmedboh@yahoo.com'),
('Amine', '123456', 0, 'Karoui', 'Amine', 'aminekaroui7@gmail.com'),
('Yahya', '123456', 0, 'Derbeli', 'Yahya', 'derbeliy97@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

DROP TABLE IF EXISTS `produit`;
CREATE TABLE IF NOT EXISTS `produit` (
  `id_produit` int(11) NOT NULL COMMENT 'L''id de consomation',
  `libellé` varchar(11) NOT NULL COMMENT 'Le nom de la consommation',
  `prix` int(11) NOT NULL COMMENT 'le prix de la consommation',
  PRIMARY KEY (`id_produit`),
  UNIQUE KEY `id_cons` (`id_produit`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `produit`
--

INSERT INTO `produit` (`id_produit`, `libellé`, `prix`) VALUES
(1, 'soda', 4),
(2, 'serviette', 55),
(3, 'eau', 3),
(4, 'pettit dej', 20),
(5, 'plat', 30);

-- --------------------------------------------------------

--
-- Structure de la table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
CREATE TABLE IF NOT EXISTS `reservation` (
  `id_res` int(11) NOT NULL AUTO_INCREMENT COMMENT 'L''id de réservation',
  `id_clt` int(11) NOT NULL COMMENT 'L''id de client',
  `id_chamb` int(11) NOT NULL,
  `dateArr` date NOT NULL COMMENT 'Date Arrivé du client',
  `dateDep` date NOT NULL COMMENT 'Date départ du client',
  PRIMARY KEY (`id_res`),
  KEY `id_res` (`id_res`) USING BTREE,
  KEY `id_chamb` (`id_chamb`) USING BTREE,
  KEY `id_clt` (`id_clt`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `chambre`
--
ALTER TABLE `chambre`
  ADD CONSTRAINT `id_chamb` FOREIGN KEY (`id_res`) REFERENCES `reservation` (`id_chamb`);

--
-- Contraintes pour la table `consommation`
--
ALTER TABLE `consommation`
  ADD CONSTRAINT `id_clt` FOREIGN KEY (`id_clt`) REFERENCES `client` (`id_clt`),
  ADD CONSTRAINT `id_produit` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
